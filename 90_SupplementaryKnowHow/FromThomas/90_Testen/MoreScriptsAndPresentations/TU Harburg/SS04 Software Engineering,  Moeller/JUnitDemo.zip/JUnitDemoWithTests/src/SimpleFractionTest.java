import junit.framework.TestCase;

/*
 * Created on Oct 30, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author David
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SimpleFractionTest extends TestCase {

    private SimpleFraction f1, f2;

	/**
	 * Constructor for SimpleFractionTest.
	 * @param arg0
	 */
	public SimpleFractionTest(String arg0) {
		super(arg0);
	}

	/*
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		f1 = new SimpleFraction(15, 25);
		f2 = new SimpleFraction(-27, 6);
	}

	public void testSimplify() {
		f1.simplify();
		assertEquals(3, f1.getNumerator());
		assertEquals(5, f1.getDenominator());

        /*
		f2.simplify();
		assertEquals(-9, f1.getNumerator());
		assertEquals(2, f1.getDenominator());
		*/
	}

	public void testGetDenominator() {
		int result = f1.getDenominator();
		assertTrue("getDenominator() returned" +result +" instead of 25.", result==25);

		result = f2.getDenominator();
		assertEquals(6, result);
	}

}
